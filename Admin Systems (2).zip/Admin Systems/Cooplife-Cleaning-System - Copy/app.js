/* =========================================================
   COOPLIFE INSURANCE LTD
   CLEANING ATTENDANCE SYSTEM
   ========================================================= */


const monthNames = [

    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"

];


let attendance = [];

let holidays = [];


/* =========================================================
   START SYSTEM
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    populateMonths();

    const today = new Date();

    document.getElementById("month").value =
        today.getMonth();

    document.getElementById("year").value =
        today.getFullYear();


    document
        .getElementById("rate")
        .addEventListener("input", updateCalculations);

    document
        .getElementById("workers3")
        .addEventListener("input", updateCalculations);

    document
        .getElementById("workers1")
        .addEventListener("input", updateCalculations);

    document
        .getElementById("extra")
        .addEventListener("input", updateCalculations);


    generateCalendar();

});


/* =========================================================
   MONTH DROPDOWN
   ========================================================= */

function populateMonths() {

    const select =
        document.getElementById("month");

    monthNames.forEach(function (month, index) {

        const option =
            document.createElement("option");

        option.value = index;

        option.textContent = month;

        select.appendChild(option);

    });

}


/* =========================================================
   DATE HELPERS
   ========================================================= */

function pad(number) {

    return String(number).padStart(2, "0");

}


function dateKey(year, month, day) {

    return (
        year +
        "-" +
        pad(month + 1) +
        "-" +
        pad(day)
    );

}


function getDateObject(key) {

    return new Date(key + "T00:00:00");

}


function isWeekend(date) {

    const day =
        date.getDay();

    return day === 0 || day === 6;

}


/* =========================================================
   HOLIDAY CHECK
   ========================================================= */

function getHoliday(key) {

    return holidays.find(function (holiday) {

        return holiday.date === key;

    });

}


/* =========================================================
   GENERATE CALENDAR
   ========================================================= */

function generateCalendar() {

    const month =
        Number(
            document.getElementById("month").value
        );

    const year =
        Number(
            document.getElementById("year").value
        );


    document.getElementById("monthTitle").textContent =
        monthNames[month];


    const daysInMonth =
        new Date(
            year,
            month + 1,
            0
        ).getDate();


    /*
       Keep previously entered attendance
       where possible.
    */

    const previous =
        {};

    attendance.forEach(function (row) {

        previous[row.date] = row;

    });


    attendance = [];


    for (
        let day = 1;
        day <= daysInMonth;
        day++
    ) {

        const key =
            dateKey(
                year,
                month,
                day
            );


        const date =
            getDateObject(key);


        const weekend =
            isWeekend(date);


        const holiday =
            getHoliday(key);


        const old =
            previous[key];


        let floor3 = 0;
        let floor1 = 0;


        if (old) {

            floor3 =
                old.floor3;

            floor1 =
                old.floor1;

        }

        else if (
            !weekend &&
            !holiday
        ) {

            floor3 =
                Number(
                    document.getElementById("workers3").value
                );

            floor1 =
                Number(
                    document.getElementById("workers1").value
                );

        }


        attendance.push({

            date: key,

            floor3: floor3,

            floor1: floor1,

            note: old
                ? old.note
                : ""

        });

    }


    renderHolidayRows();

    renderAttendance();

    updateCalculations();

}


/* =========================================================
   RENDER ATTENDANCE TABLE
   ========================================================= */

function renderAttendance() {

    const tbody =
        document.getElementById("attendanceBody");


    tbody.innerHTML = "";


    attendance.forEach(function (row, index) {

        const date =
            getDateObject(row.date);


        const weekend =
            isWeekend(date);


        const holiday =
            getHoliday(row.date);


        const tr =
            document.createElement("tr");


        if (weekend) {

            tr.className =
                "weekend-row";

        }

        else if (holiday) {

            tr.className =
                "holiday-row-table";

        }


        /* ================= DATE ================= */

        const dateCell =
            document.createElement("td");

        dateCell.className =
            "date-cell";


        let dateText =
            date.toLocaleDateString(
                "en-GB",
                {
                    day: "2-digit",
                    month: "short",
                    year: "numeric"
                }
            );


        if (weekend) {

            const dayName =
                date.toLocaleDateString(
                    "en-US",
                    {
                        weekday: "short"
                    }
                );

            dateText =
                dayName +
                " " +
                dateText;

        }


        if (holiday) {

            dateText =
                holiday.name +
                " " +
                dateText;

        }


        dateCell.textContent =
            dateText;


        tr.appendChild(dateCell);


        /* ================= 03RD FLOOR ================= */

        const floor3Cell =
            document.createElement("td");


        const floor3Input =
            document.createElement("input");


        floor3Input.type =
            "number";

        floor3Input.min =
            "0";

        floor3Input.step =
            "1";

        floor3Input.value =
            row.floor3;

        floor3Input.className =
            "attendance-input";


        if (weekend || holiday) {

            floor3Input.disabled =
                true;

        }


        floor3Input.addEventListener(
            "input",
            function () {

                attendance[index].floor3 =
                    Number(
                        this.value || 0
                    );

                updateCalculations();

                updateTotalCell(
                    index,
                    tr
                );

            }
        );


        floor3Cell.appendChild(
            floor3Input
        );


        tr.appendChild(
            floor3Cell
        );


        /* ================= 01ST FLOOR ================= */

        const floor1Cell =
            document.createElement("td");


        const floor1Input =
            document.createElement("input");


        floor1Input.type =
            "number";

        floor1Input.min =
            "0";

        floor1Input.step =
            "1";

        floor1Input.value =
            row.floor1;

        floor1Input.className =
            "attendance-input";


        if (weekend || holiday) {

            floor1Input.disabled =
                true;

        }


        floor1Input.addEventListener(
            "input",
            function () {

                attendance[index].floor1 =
                    Number(
                        this.value || 0
                    );

                updateCalculations();

                updateTotalCell(
                    index,
                    tr
                );

            }
        );


        floor1Cell.appendChild(
            floor1Input
        );


        tr.appendChild(
            floor1Cell
        );


        /* ================= TOTAL DAYS ================= */

        const totalCell =
            document.createElement("td");

        totalCell.className =
            "total-cell";


        if (weekend || holiday) {

            totalCell.textContent =
                "-";

        }

        else {

            totalCell.textContent =
                Number(row.floor3) +
                Number(row.floor1);

        }


        tr.appendChild(
            totalCell
        );


        tbody.appendChild(tr);

    });

}


/* =========================================================
   UPDATE SINGLE TOTAL CELL
   ========================================================= */

function updateTotalCell(
    index,
    tr
) {

    const date =
        getDateObject(
            attendance[index].date
        );


    const holiday =
        getHoliday(
            attendance[index].date
        );


    const totalCell =
        tr.children[3];


    if (
        isWeekend(date) ||
        holiday
    ) {

        totalCell.textContent =
            "-";

        return;

    }


    totalCell.textContent =
        Number(
            attendance[index].floor3
        ) +
        Number(
            attendance[index].floor1
        );

}


/* =========================================================
   HOLIDAY MANAGEMENT
   ========================================================= */

function addHolidayRow(
    date = "",
    name = ""
) {

    const container =
        document.getElementById(
            "holidayRows"
        );


    const row =
        document.createElement("div");


    row.className =
        "holiday-row";


    row.innerHTML = `

        <input
            type="date"
            class="holiday-date"
            value="${date}"
        >

        <input
            type="text"
            class="holiday-name"
            placeholder="Holiday name"
            value="${name}"
        >

        <button
            type="button"
            onclick="removeHolidayRow(this)"
        >
            Remove
        </button>

    `;


    container.appendChild(row);


    row.querySelector(
        ".holiday-date"
    ).addEventListener(
        "change",
        holidayChanged
    );


    row.querySelector(
        ".holiday-name"
    ).addEventListener(
        "input",
        holidayChanged
    );

}


function removeHolidayRow(button) {

    button.parentElement.remove();

    readHolidayRows();

    generateCalendar();

}


function readHolidayRows() {

    holidays = [];


    document
        .querySelectorAll(".holiday-row")
        .forEach(function (row) {

            const date =
                row.querySelector(
                    ".holiday-date"
                ).value;


            const name =
                row.querySelector(
                    ".holiday-name"
                ).value.trim();


            if (date) {

                holidays.push({

                    date: date,

                    name:
                        name ||
                        "Public Holiday"

                });

            }

        });

}


function holidayChanged() {

    readHolidayRows();

    generateCalendar();

}


function renderHolidayRows() {

    const container =
        document.getElementById(
            "holidayRows"
        );


    container.innerHTML = "";


    holidays.forEach(function (holiday) {

        addHolidayRow(
            holiday.date,
            holiday.name
        );

    });

}


/* =========================================================
   CALCULATIONS
   ========================================================= */

function updateCalculations() {

    readHolidayRows();


    let workingDays = 0;

    let floor3Total = 0;

    let floor1Total = 0;


    attendance.forEach(function (row) {

        const date =
            getDateObject(row.date);


        const weekend =
            isWeekend(date);


        const holiday =
            getHoliday(row.date);


        if (
            !weekend &&
            !holiday
        ) {

            workingDays++;

            floor3Total +=
                Number(row.floor3 || 0);

            floor1Total +=
                Number(row.floor1 || 0);

        }

    });


    const rate =
        Number(
            document.getElementById(
                "rate"
            ).value || 0
        );


    const workers3 =
        Number(
            document.getElementById(
                "workers3"
            ).value || 0
        );


    const workers1 =
        Number(
            document.getElementById(
                "workers1"
            ).value || 0
        );


    const extra =
        Number(
            document.getElementById(
                "extra"
            ).value || 0
        );


    /*
       EXACT PAYMENT FORMULA

       One day × Days × 02 Workers

       Example:

       Rs.2,500 × 19 × 2
       = Rs.100,000
    */

    const totalWorkers =
        workers3 + workers1;


    const monthlyPayment =
        rate *
        workingDays *
        totalWorkers;


    const grandTotal =
        monthlyPayment +
        extra;


    /* ================= DISPLAY ================= */

    document.getElementById(
        "paymentRate"
    ).textContent =
        formatNumber(rate);


    document.getElementById(
        "paymentDays"
    ).textContent =
        workingDays;


    document.getElementById(
        "paymentWorkers"
    ).textContent =
        totalWorkers;


    document.getElementById(
        "paymentTotal"
    ).textContent =
        formatNumber(monthlyPayment);


    document.getElementById(
        "totalWorkingDays"
    ).textContent =
        workingDays;


    document.getElementById(
        "extraPayment"
    ).textContent =
        extra > 0
            ? formatNumber(extra)
            : "-";


    document.getElementById(
        "monthlyPayment"
    ).textContent =
        formatNumber(monthlyPayment);


    document.getElementById(
        "extraPaymentBottom"
    ).textContent =
        extra > 0
            ? formatNumber(extra)
            : "-";


    document.getElementById(
        "grandTotal"
    ).textContent =
        formatNumber(grandTotal);

}


/* =========================================================
   NUMBER FORMAT
   ========================================================= */

function formatNumber(number) {

    return Number(number || 0)
        .toLocaleString(
            "en-US",
            {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }
        );

}


/* =========================================================
   SAVE MONTH
   ========================================================= */

function saveMonth() {

    readHolidayRows();


    const month =
        Number(
            document.getElementById(
                "month"
            ).value
        );


    const year =
        Number(
            document.getElementById(
                "year"
            ).value
        );


    const data = {

        month: month,

        year: year,

        rate:
            document.getElementById(
                "rate"
            ).value,

        workers3:
            document.getElementById(
                "workers3"
            ).value,

        workers1:
            document.getElementById(
                "workers1"
            ).value,

        extra:
            document.getElementById(
                "extra"
            ).value,

        holidays:
            holidays,

        attendance:
            attendance

    };


    const key =
        "cooplife_" +
        year +
        "_" +
        pad(month + 1);


    localStorage.setItem(
        key,
        JSON.stringify(data)
    );


    alert(
        "Month saved successfully."
    );

}


/* =========================================================
   LOAD MONTH
   ========================================================= */

function loadMonth() {

    const month =
        Number(
            document.getElementById(
                "month"
            ).value
        );


    const year =
        Number(
            document.getElementById(
                "year"
            ).value
        );


    const key =
        "cooplife_" +
        year +
        "_" +
        pad(month + 1);


    const saved =
        localStorage.getItem(key);


    if (!saved) {

        alert(
            "No saved record found for this month."
        );

        return;

    }


    const data =
        JSON.parse(saved);


    document.getElementById(
        "rate"
    ).value =
        data.rate;


    document.getElementById(
        "workers3"
    ).value =
        data.workers3;


    document.getElementById(
        "workers1"
    ).value =
        data.workers1;


    document.getElementById(
        "extra"
    ).value =
        data.extra;


    holidays =
        data.holidays || [];


    attendance =
        data.attendance || [];


    renderHolidayRows();

    renderAttendance();

    updateCalculations();


    alert(
        "Saved month loaded successfully."
    );

}


/* =========================================================
   EXCEL EXPORT
   ========================================================= */

function exportExcel() {

    if (
        typeof XLSX ===
        "undefined"
    ) {

        alert(
            "Excel library is not available. Please connect to the internet and reload the page."
        );

        return;

    }


    readHolidayRows();


    const month =
        Number(
            document.getElementById(
                "month"
            ).value
        );


    const year =
        Number(
            document.getElementById(
                "year"
            ).value
        );


    const rate =
        Number(
            document.getElementById(
                "rate"
            ).value || 0
        );


    const workers3 =
        Number(
            document.getElementById(
                "workers3"
            ).value || 0
        );


    const workers1 =
        Number(
            document.getElementById(
                "workers1"
            ).value || 0
        );


    const extra =
        Number(
            document.getElementById(
                "extra"
            ).value || 0
        );


    const totalWorkers =
        workers3 + workers1;


    /*
       Calculate working days
    */

    let workingDays = 0;

    let floor3Total = 0;

    let floor1Total = 0;


    attendance.forEach(function (row) {

        const date =
            getDateObject(row.date);


        const holiday =
            getHoliday(row.date);


        if (
            !isWeekend(date) &&
            !holiday
        ) {

            workingDays++;

            floor3Total +=
                Number(row.floor3 || 0);

            floor1Total +=
                Number(row.floor1 || 0);

        }

    });


    const monthlyPayment =
        rate *
        workingDays *
        totalWorkers;


    const grandTotal =
        monthlyPayment +
        extra;


    /* =====================================================
       CREATE EXACT REPORT STRUCTURE
       ===================================================== */

    const rows = [];


    /*
       Row 1
    */

    rows.push([
        "Cooplife Insurance Ltd"
    ]);


    /*
       Row 2
    */

    rows.push([
        "Cleaning Days",
        "",
        "Month of " +
        monthNames[month]
    ]);


    /*
       Row 3 - headers
    */

    rows.push([
        "Date",
        "03rd Floor",
        "01st Floor",
        "Total days"
    ]);


    /*
       Calendar rows
    */

    attendance.forEach(function (row) {

        const date =
            getDateObject(row.date);


        const holiday =
            getHoliday(row.date);


        let dateText =
            date.toLocaleDateString(
                "en-GB",
                {
                    day: "2-digit",
                    month: "short",
                    year: "numeric"
                }
            );


        if (isWeekend(date)) {

            const dayName =
                date.toLocaleDateString(
                    "en-US",
                    {
                        weekday: "short"
                    }
                );


            dateText =
                dayName +
                " " +
                dateText;

        }


        if (holiday) {

            dateText =
                holiday.name +
                " " +
                dateText;

        }


        let floor3 = "";
        let floor1 = "";
        let total = "-";


        if (
            !isWeekend(date) &&
            !holiday
        ) {

            floor3 =
                Number(row.floor3 || 0);

            floor1 =
                Number(row.floor1 || 0);

            total =
                floor3 +
                floor1;

        }


        rows.push([
            dateText,
            floor3,
            floor1,
            total
        ]);

    });


    /*
       Total days
    */

    rows.push([
        "Total days",
        floor3Total,
        floor1Total,
        floor3Total + floor1Total
    ]);


    /*
       Blank rows
    */

    rows.push([]);
    rows.push([]);


    /*
       Payment section
    */

    rows.push([
        "",
        "Rs",
        ""
    ]);


    rows.push([
        "",
        "One day",
        rate
    ]);


    rows.push([
        "",
        "Days",
        workingDays
    ]);


    rows.push([
        "",
        "02 Workers",
        totalWorkers
    ]);


    rows.push([
        "",
        "Total",
        monthlyPayment
    ]);


    rows.push([]);


    rows.push([
        "",
        "Total Working days",
        workingDays
    ]);


    rows.push([
        "",
        "Maximum Extra Payment",
        extra > 0 ? extra : "-"
    ]);


    rows.push([]);


    rows.push([
        "",
        "Monthly Payment",
        monthlyPayment
    ]);


    rows.push([
        "",
        "Maximum Extra Payment",
        extra > 0 ? extra : "-"
    ]);


    rows.push([
        "",
        "",
        grandTotal
    ]);


    /* =====================================================
       CREATE WORKBOOK
       ===================================================== */

    const workbook =
        XLSX.utils.book_new();


    const worksheet =
        XLSX.utils.aoa_to_sheet(rows);


    /*
       Column widths
    */

    worksheet["!cols"] = [

        {
            wch: 28
        },

        {
            wch: 25
        },

        {
            wch: 20
        },

        {
            wch: 18
        }

    ];


    /* =====================================================
       MERGE TITLE CELLS
       ===================================================== */

    worksheet["!merges"] = [

        {
            s: {
                r: 0,
                c: 0
            },

            e: {
                r: 0,
                c: 3
            }
        }

    ];


    /*
       Add worksheet
    */

    XLSX.utils.book_append_sheet(
        workbook,
        worksheet,
        "Cleaning Days"
    );


    /*
       Filename
    */

    const filename =
        "Cooplife_Cleaning_Days_" +
        year +
        "_" +
        pad(month + 1) +
        ".xlsx";


    /*
       Download
    */

    XLSX.writeFile(
        workbook,
        filename
    );

}


/* =========================================================
   END
   ========================================================= */
